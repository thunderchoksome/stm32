#ifndef __EXTI_H
#define __EXIT_H	 
#include "sys.h" 	 
void EXTIX_Init(void);//�ⲿ�жϳ�ʼ��		 					    
#endif

