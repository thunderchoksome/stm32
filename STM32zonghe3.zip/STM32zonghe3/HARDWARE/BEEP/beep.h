#ifndef __BEEP_H
#define __BEEP_H
#include "sys.h"
void BeepInit(void);
#endif
