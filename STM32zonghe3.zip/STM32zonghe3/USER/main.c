#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "rtc.h" 
#include "usart.h"
#include "beep.h"
#include "exti.h"
u8 sign=0;


 
 int main(void)
 {	 
 	u8 t=0;	
	delay_init();	    	 //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//�����ж����ȼ�����Ϊ��2��2λ��ռ���ȼ���2λ��Ӧ���ȼ�
 	LED_Init();			     //LED�˿ڳ�ʼ��
	uart_init(115200);	 	//���ڳ�ʼ��Ϊ115200
	LCD_Init();			 	
	RTC_Init();	  			//RTC��ʼ��
	BeepInit();
	EXTIX_Init();
	POINT_COLOR=RED;//��������Ϊ��ɫ 	
  LCD_ShowString(180,384,200,32,32,"  :  :  "); 
	LCD_ShowString(180,364,200,16,16,"    -  -  ");	
	POINT_COLOR=BLUE;//��������Ϊ��ɫ
	while(1)
	{								    
		if(t!=calendar.sec)
		{
			t=calendar.sec;
			LCD_ShowNum(180,364,calendar.w_year,4,16);									  
			LCD_ShowNum(220,364,calendar.w_month,2,16);									  
			LCD_ShowNum(244,364,calendar.w_date,2,16);	 
			switch(calendar.week)
			{
				case 0:
					LCD_ShowString(276,364,200,16,16,"Sun ");
					break;
				case 1:
					LCD_ShowString(276,364,200,16,16,"Mon ");
					break;
				case 2:
					LCD_ShowString(276,364,200,16,16,"Tue ");
					break;
				case 3:
					LCD_ShowString(276,364,200,16,16,"Wed ");
					break;
				case 4:
					LCD_ShowString(276,364,200,16,16,"Thur");
					break;
				case 5:
					LCD_ShowString(276,364,200,16,16,"Fri ");
					break;
				case 6:
					LCD_ShowString(276,364,200,16,16,"Sat ");
					break;  
			}
			LCD_ShowNum(180,384,calendar.hour,2,32);									  
			LCD_ShowNum(228,384,calendar.min,2,32);									  
			LCD_ShowNum(276,384,calendar.sec,2,32);
			LED0=!LED0;
		}	
		delay_ms(10);								  
	};  
 }

