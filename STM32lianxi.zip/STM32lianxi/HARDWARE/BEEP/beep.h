#ifndef __BEEP_H
#define __BEEP_H
#include "sys.h"
#define BEEP PBout(8) 
void BeepInit(void);
void BeepMode(unsigned char mode);
#endif
