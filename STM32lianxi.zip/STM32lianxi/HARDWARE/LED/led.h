#ifndef __LED_H
#define __LED_H
#include "sys.h" 
#define LED0 PBout(5)// DS0 
#define LED1 PEout(5)// DS1 
void LedInit(void);
void LedMode(unsigned char mode);
#endif
