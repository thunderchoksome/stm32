#include "stm32f10x.h"
#include "led.h"
#include "beep.h"
#include "key.h"
#include "delay.h"

int main()
{
	unsigned int sym;
	delay_init();
	ledinit();
	beepinit();
	keyinit();
	
	
	while(1)
	{
		sym=keyscan(1);
		if(sym)
		{
			switch(sym)
			{
				case 1:BEEP=~BEEP;break;
				case 2:LED0=~LED0;break;
				case 3:LED0=~LED0;LED1=~LED1;break;
			}
		}
		else delay_ms(10);
	}
	
}

