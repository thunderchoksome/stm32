#ifndef __beep_h
#define __beep_h

#define BEEP PBout(8)
void beepinit(void);

#endif
