#include "stm32f10x.h"
#include "key.h"
#include "delay.h"

void keyinit(void)
{
	GPIO_InitTypeDef GPIO_InitStruct1;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);
	
	GPIO_InitStruct1.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStruct1.GPIO_Pin=GPIO_Pin_3|GPIO_Pin_4;
	GPIO_Init(GPIOE,&GPIO_InitStruct1);
	
	GPIO_InitStruct1.GPIO_Mode=GPIO_Mode_IPD;
	GPIO_InitStruct1.GPIO_Pin=GPIO_Pin_0;
	GPIO_Init(GPIOA,&GPIO_InitStruct1);
	
}

unsigned int keyscan(unsigned int mode)
{
	static unsigned int sign=1;
	if(mode==1) sign=1;
	if(sign==1&&(KEY0==0|KEY1==0|WK_UP==1))
	{
		delay_ms(10);//����
		sign=0;
		if(KEY0==0) return 1;
			else if(KEY1==0) return 2;
				else if(WK_UP==1) return 3;
	}
	else if(KEY0==1|KEY1==1|WK_UP==0)sign=1;
		return 0;
}
