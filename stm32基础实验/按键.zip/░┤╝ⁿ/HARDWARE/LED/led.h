#ifndef __led_h
#define __led_h

#define LED0 PBout(5)
#define LED1 PEout(5)
void ledinit(void);

#endif
