#include "stm32f10x.h"
#include "delay.h"
#include "beep.h"
int main()
{
	delay_init();
	BEEP_Init();
	while(1)
	{
		play_music();
	}
}
 

