#ifndef __LED_H
#define __LED_H

void LED_Init(void);

#endif
